/*Classe du Contrôleur
*@author Antoine Blondeau
*/
public class Principal


{
	/*Méthode du contrôleur
	*@param args Arguments à l'exécution
	*/
	public static void main(String []args)
	{
		IHM i = new IHM();
	}
}